import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-app',
  templateUrl: './get-app.component.html',
  styleUrls: ['./get-app.component.css']
})
export class GetAppComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
