import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-search-box',
  templateUrl: './app-search-box.component.html',
  styleUrls: ['./app-search-box.component.css']
})
export class AppSearchBoxComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
