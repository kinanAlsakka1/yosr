import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-ads',
  templateUrl: './app-ads.component.html',
  styleUrls: ['./app-ads.component.css']
})
export class AppAdsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
